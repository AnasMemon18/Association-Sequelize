const Sequelize = require("sequelize");

const sequelize = new Sequelize(
    'node_complete',
    'root',
    'Password@123', 
    {
        Server: 'localhost',
        dialect : 'mysql'
    }
);

sequelize.authenticate().then(()=>{
    console.log("Database Connected");
}).catch((err)=>{
    console.log("error",err);
});

module.exports = sequelize;