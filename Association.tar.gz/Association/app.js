const express = require("express");

const bodyParser = require("body-parser");
const sequelize = require("./server");
const employee = require("./models/employee.model");
const role = require("./models/role.model");
const detail = require('./models/detail.model');
const details = require("./models/detail.model");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");

app.set("views", "views");

employee.hasOne(detail);

// Inner join                                                                                                                                                                                                                                                                                                                   
employee
  .findAll({
    include : [{
      model : detail,
      required : true
    }],
  })
  .then((result) => {
    var result = result;
    console.log("Inner Join");
    console.log(JSON.stringify(result, null, 2));

  })
  .catch((err) => {
    throw err;
  });




// Left join

// app.get("/index",(req, res, next) => {
//   employee
//     .findAll({
//       include: [
//         {
//           model: details,
//         },
//       ],
//     })
//     .then((result) => {
//       var result = result;
//       console.log("Left Join");
//       // console.log(JSON.stringify(result, null, 3));
//       res.render("index", {data : result});
//     })
//     .catch((err) => {
//       throw err;
//     });
// });




// right join
// app.get("/index",(req, res, next) => {
//   role
//     .findAll({
//       include: [
//         {
//           model: employee,
//           right: true
//         },
//       ],
//     })
//     .then((result) => {
//       var result = result;
//       console.log("Right Join");
//       // console.log(JSON.stringify(result, null, 3));
//       res.render("index", {data : result});
//     })
//     .catch((err) => {
//       throw err;
//     });
// });

sequelize
  .sync()
  .then((result) => {
    // console.log(result);
    app.listen(8888);
  })
  .catch((err) => {
    console.log(err);
  });