const Sequelize = require("sequelize");

const sequelize = require('../server');

const details = sequelize.define("Detail", {
   id:{
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true
   },
   salary:{
    type: Sequelize.INTEGER,
    allowNull: false,
    required: true
   },
   address:{
    type: Sequelize.STRING,
    allowNull: true,
    required: true
   }
}, {timestamps:false});

module.exports = details;