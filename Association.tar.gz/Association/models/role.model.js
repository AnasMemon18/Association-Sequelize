const Sequelize = require("sequelize");

const sequelize = require('../server');

const role = sequelize.define("Role", {
     role : {
        type: Sequelize.DataTypes.STRING,
        allowNull : false
    }
}, {timestamps:false});

module.exports = role;