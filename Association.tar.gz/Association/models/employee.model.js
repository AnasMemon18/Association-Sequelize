const Sequelize = require("sequelize");

const sequelize = require('../server');

const employee = sequelize.define("Employee", {
    name : {
        type: Sequelize.DataTypes.STRING,
        allowNull : false
    },
    email : {
        type: Sequelize.DataTypes.STRING,
        allowNull : false
    },
    password : {
        type : Sequelize.DataTypes.STRING,
        allowNull: false
    },
    tech : {
        type : Sequelize.DataTypes.STRING,
        allowNull: false
    },
    mobileNumber : {
        type : Sequelize.DataTypes.STRING,
        allowNull : false
    }
}, {timestamps:false});

module.exports = employee;